<x-filament-widgets::widget>
    <form wire:submit.prevent>
        {{ $this->form }}
    </form>
</x-filament-widgets::widget>
